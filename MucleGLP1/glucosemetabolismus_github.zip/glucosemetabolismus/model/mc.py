"""Monte-Carlo-Unsicherheit: kalibrierte Parameter (Posterior) + Annahmen [A] gleichzeitig variiert."""
import numpy as np, json, warnings, sys
import model as m, groups as gr, intervention as iv, scenarios as sc
warnings.filterwarnings("ignore")
rng = np.random.default_rng(42); rng_gain = np.random.default_rng(7)   # eigener Strom: uebrige Ziehungen unveraendert
C = json.load(open("calibration.json")); keys = C["keys"]; z = np.array(C["z"]); cov = np.array(C["cov"])
N = int(sys.argv[1]) if len(sys.argv) > 1 else 300
base_alpha = dict(iv.ALPHA); base_glp = dict(iv.GLP1); base_t2d = dict(iv.GLP1_T2D)
res = []
for n in range(N):
    zz = rng.multivariate_normal(z, cov)
    par = dict(m.LIT, **{k: float(np.exp(v)) for k, v in zip(keys, zz)})
    par["GE_max"] = float(np.clip(par["GE_max"], 0.401, 0.719)); par["sP"] = float(np.clip(par["sP"], 0.05, 0.95))
    par["musc_SI"] = rng.uniform(0.7, 0.9); par["w_glucagon"] = rng.uniform(0.4, 0.8); par["musc_ii"] = rng.uniform(0.15, 0.45)
    A = dict(s_fat=rng.uniform(0.5, 1.0), lm=rng.uniform(0.5, 1.0), q_train=rng.uniform(1.0, 1.3), qmult=rng.uniform(0.8, 1.2),
             beta_t2d=rng.uniform(0.25, 0.55), a_ngt=rng.uniform(0.5, 1.0), a_igt=rng.uniform(0.0, 1.0), a_t2d=rng.uniform(0.0, 0.5),
             isr=rng.uniform(1.2, 1.7), isr_t2d=rng.uniform(1.6, 2.6), glc=rng.uniform(0.80, 0.92), gain=rng_gain.uniform(0.8, 1.5))
    try:
        gr.CAL = par; gr.GROUPS, _, _ = gr.build_groups(par, A["qmult"], A["beta_t2d"])
        iv.ALPHA = {"gesund": 1.0, "adipös NGT": A["a_ngt"], "adipös IGT": A["a_igt"], "T2D": A["a_t2d"]}
        iv.GLP1 = dict(drug_isr=A["isr"], drug_glucagon=A["glc"], drug_ge=1.0)
        iv.GLP1_T2D = dict(drug_isr=A["isr_t2d"], drug_glucagon=A["glc"], drug_ge=1.0)
        opt = dict(par=par, lm=A["lm"], s_fat=A["s_fat"], q_train=A["q_train"], gain_FFM=A["gain"])
        row = dict(A=A, cal={k: par[k] for k in keys}, scen={}, shap={})
        h = gr.summary(*gr.run("gesund", par=par)); row["healthy"] = h
        for g in sc.GROUPS_OB:
            row["scen"][g] = {k: iv.metrics(q)[0] for k, q in sc.scenario_defs(g, opt).items()}
            phi, v0, v1 = sc.shapley(g, "Gmean120", opt); row["shap"][g] = phi
        res.append(row)
    except Exception as e:
        print("Fehler", n, e)
    if n % 50 == 0: print(n, flush=True)
json.dump(res, open("mc.json", "w"))
print("fertig", len(res))

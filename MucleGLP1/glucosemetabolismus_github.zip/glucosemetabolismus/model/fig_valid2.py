import numpy as np, warnings, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")
import intervention as iv
b = iv.metrics(iv.make("adipös NGT"))[0]; s = iv.metrics(iv.make("adipös NGT", iv.MK_xFM[-1], iv.MK_xFFM[-1]))[0]
mod = {k: 100 * (s[k] / b[k] - 1) for k in ("I0", "Gmean120", "Imean120")}
g0 = []; 
for g in ["adipös NGT", "adipös IGT"]:
    b0 = iv.metrics(iv.make(g))[0]; s1 = iv.metrics(iv.make(g, **iv.STEP1, drug=iv.GLP1))[0]; g0.append((b0["G0"], s1["G0"]))
base = 0.563 * g0[0][0] + 0.437 * g0[1][0]; after = 0.563 * g0[0][1] + 0.437 * g0[1][1]
step_mod = 100 * (after / base - 1); step_dat = 100 * (-8.35 / 95.4)
rows = [("Nüchterninsulin", -48, mod["I0"], "passt"),
        ("Glukose im oGTT", 100 * (16665 / 16558 - 1), mod["Gmean120"], "passt (Abweichung < 10 Prozentpunkte)"),
        ("Insulin im oGTT", 100 * (9534 / 12365 - 1), mod["Imean120"], "Modell sinkt etwa doppelt so stark"),
        ("Nüchternglukose", step_dat, step_mod, "passt")]
print([(r[0], round(r[1]), round(r[2])) for r in rows])
INK, INK2, GRAY, BLUE, ORANGE, GREEN = "#14213D", "#52514e", "#a9a8a3", "#2a6fdb", "#c26a17", "#1f9e89"
plt.rcParams.update({"font.size": 15, "axes.spines.top": False, "axes.spines.right": False, "axes.spines.left": False})
fig, ax = plt.subplots(figsize=(16, 5.6))
y = np.array([0, 1, 2, 3.6]); h = 0.34
for yi, (lab, d, mv, verdict) in zip(y, rows):
    ax.barh(yi - h / 2, d, h, color=GRAY); ax.barh(yi + h / 2, mv, h, color=BLUE)
    for v, yy in [(d, yi - h / 2), (mv, yi + h / 2)]:
        ax.text(v + (-1 if v < 0 else 1), yy, f"{v:+.0f} %", va="center", ha="right" if v < 0 else "left", fontsize=14, color=INK)
    col = ORANGE if "doppelt" in verdict else GREEN
    ax.text(14, yi, verdict, va="center", fontsize=15, color=col, fontweight="bold")
ax.set_yticks(y, [r[0] for r in rows], fontsize=16); ax.invert_yaxis()
ax.axvline(0, color=INK, lw=1); ax.set_xlim(-68, 70); ax.set_xticks([-60, -40, -20, 0])
ax.set_xlabel("Änderung gegenüber vorher (%)", color=INK2); ax.grid(axis="x", color="#ececea"); ax.tick_params(axis="y", length=0)
ax.text(-67, -0.75, "Gewichtsverlust 16 % ohne Medikament (Magkos 2016)", fontsize=15, fontweight="bold", color=INK)
ax.text(-67, 2.85, "Semaglutid 2,4 mg, 68 Wochen (STEP 1)", fontsize=15, fontweight="bold", color=INK)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=GRAY, label="gemessen"), Patch(color=BLUE, label="Modell (Vorhersage)")], loc="lower right", fontsize=14, frameon=False, bbox_to_anchor=(1.0, -0.02))
ax.set_ylim(4.1, -1.05)
fig.tight_layout(); fig.savefig("fig/f3b_validierung.png", dpi=160)

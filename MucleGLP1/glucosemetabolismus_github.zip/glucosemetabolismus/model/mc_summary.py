import json, numpy as np
R = json.load(open("mc.json")); G = ["adipös NGT", "adipös IGT", "T2D"]
q = lambda a: (np.percentile(a, 50), np.percentile(a, 5), np.percentile(a, 95))
out = {}
for g in G:
    out[g] = {}
    fat = np.array([r["shap"][g]["fat_periph"] + r["shap"][g]["fat_liver"] for r in R])
    lean = np.array([r["shap"][g]["lean"] for r in R]); drug = np.array([r["shap"][g]["isr"] + r["shap"][g]["glucagon"] for r in R])
    out[g]["fat"] = q(fat); out[g]["lean"] = q(lean); out[g]["drug"] = q(drug); out[g]["ratio"] = q(np.abs(fat / lean))
    for k in ["GLP-1 (STEP 1)", "GLP-1 + Muskelerhalt", "GLP-1, nur Fettverlust (theoretisch)", "Krafttraining ohne GLP-1"]:
        d = np.array([r["scen"][g][k]["Gmean120"] - r["scen"][g]["Ausgang"]["Gmean120"] for r in R]); out[g][k] = q(d)
    pot = np.array([r["scen"][g]["GLP-1, nur Fettverlust (theoretisch)"]["Gmean120"] - r["scen"][g]["GLP-1 (STEP 1)"]["Gmean120"] for r in R])
    out[g]["potential"] = q(pot)
    share = np.array([(r["scen"][g]["GLP-1, nur Fettverlust (theoretisch)"]["Gmean120"] - r["scen"][g]["GLP-1 (STEP 1)"]["Gmean120"]) /
                      (r["scen"][g]["GLP-1 (STEP 1)"]["Gmean120"] - r["scen"][g]["Ausgang"]["Gmean120"]) for r in R])
    out[g]["potential_rel"] = q(-100 * share)
    print(g); [print("  %-40s %+.2f [%+.2f; %+.2f]" % (k, *v)) for k, v in out[g].items()]
hg = np.array([[r["healthy"][k] for k in ("G120", "Imean120")] for r in R]); print("gesund G120/Imean120 5-95:", np.percentile(hg, [5, 50, 95], axis=0).round(2))
json.dump(out, open("mc_summary.json", "w"), indent=1)

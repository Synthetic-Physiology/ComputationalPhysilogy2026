"""Kalibrierung der gesunden Referenz: Maximum-a-posteriori innerhalb der Literaturstreuung."""
import numpy as np, json, warnings
from scipy.optimize import least_squares
import model as m
warnings.filterwarnings("ignore")
T = np.array([30, 60, 90, 120])
GD = np.array([7.72, 7.26, 6.28, 5.60]); ID = np.array([296, 328, 262, 230.])
FLUX = dict(EGP45=(0.62, 0.3), EGP210=(0.85, 0.3), MUSC=(0.26, 0.06))   # Ferrannini 1985, Kelley 1988
# Prior: Literaturwert, log-SD
PRI = dict(SG=(0.025, .35), SI_D=(9.93e-4, .30), X50_D=(330., .30), X50_L=(71., .40), sP=(0.5, .50), p2=(0.02, .50), CL=(1.6, .20),
           beta=(119., .35), RS=(800., .60), PFR=(2.0, .25), GE_max=(0.5, .20), V_dl=(1.45, .15), k_abs=(0.057, .50))
BOUNDS = dict(GE_max=(0.401, 0.719), PFR=(1.05, 3.5), sP=(0.05, 0.95))
KEYS = list(PRI)

def predict(par, t_end=300):
    q = m.build(par); t, y = m.ogtt(q, t_end)
    Ra, E, mu = m.fluxes(t, y, q)
    musc = mu[:301].sum() * q["BW"] / 1000 / q["D"]          # Anteil der Last (mg/kg/min * kg * min / mg)
    return dict(t=t, G=y[2], I=y[3], EGP=E, Ra=Ra, musc=musc, q=q)

def residuals(z, w_data=1.0):
    par = dict(m.LIT, **{k: float(np.exp(v)) for k, v in zip(KEYS, z)})
    r = predict(par)
    res = list((r["G"][T] - GD) / 0.25 * w_data) + list((r["I"][T] / ID - 1) / 0.12 * w_data)
    res += [(r["EGP"][45] - FLUX["EGP45"][0]) / FLUX["EGP45"][1], (r["EGP"][210] - FLUX["EGP210"][0]) / FLUX["EGP210"][1],
            (r["musc"] - FLUX["MUSC"][0]) / FLUX["MUSC"][1]]
    res += [(v - np.log(PRI[k][0])) / PRI[k][1] for k, v in zip(KEYS, z)]
    res += [max(r["q"]["f"] - 1.0, 0.0) / 0.01]                     # physikalisch: f <= 1
    return np.array(res)

if __name__ == "__main__":
    z0 = np.log([PRI[k][0] for k in KEYS])
    lb = [np.log(BOUNDS.get(k, (PRI[k][0] / 6, 0))[0]) for k in KEYS]
    ub = [np.log(BOUNDS.get(k, (0, PRI[k][0] * 6))[1]) for k in KEYS]
    r0 = residuals(z0); print("Start: Kosten %.1f" % (0.5 * np.sum(r0 ** 2)))
    sol = least_squares(residuals, z0, bounds=(lb, ub), x_scale=1.0, diff_step=1e-3)
    cal = {k: float(np.exp(v)) for k, v in zip(KEYS, sol.x)}
    print("MAP: Kosten %.1f" % sol.cost)
    for k in KEYS:
        print(f"  {k:7s} Literatur {PRI[k][0]:.4g} -> {cal[k]:.4g}  ({(np.log(cal[k]/PRI[k][0]))/PRI[k][1]:+.2f} SD)")
    # Unsicherheit (Laplace)
    J = sol.jac; cov = np.linalg.pinv(J.T @ J); sd = np.sqrt(np.diag(cov))
    par = dict(m.LIT, **cal); r = predict(par)
    print("G", np.round(r["G"][[0, 30, 60, 90, 120]], 2), "Daten 4.95", GD)
    print("I", np.round(r["I"][[0, 30, 60, 90, 120]]), "Daten 38", ID)
    print("EGP45 %.2f EGP210 %.2f Muskel %.2f" % (r["EGP"][45], r["EGP"][210], r["musc"]))
    json.dump(dict(cal=cal, logsd=dict(zip(KEYS, sd.tolist())), cov=cov.tolist(), keys=KEYS, cost=sol.cost, z=sol.x.tolist()), open("calibration.json", "w"), indent=1)

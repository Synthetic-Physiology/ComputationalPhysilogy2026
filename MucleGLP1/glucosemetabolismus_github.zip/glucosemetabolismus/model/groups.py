"""Gruppen aus Literaturfaktoren relativ zur kalibrierten Referenz (keine Anpassung an Gruppendaten)."""
import numpy as np, json, model as m
mg = 1 / 18.016
CAL = dict(m.LIT, **json.load(open("calibration.json"))["cal"])
OBESE = dict(BW=104.0, FM=50.0, FFM=54.0)                     # [L] STEP 1 / Magkos 2016 (FM ~50, FFM ~53-55)

def si_rel(person):
    """Ganzkoerper-Insulinsensitivitaet relativ zur Referenz (Gewichtung Aufnahme/Leber nach Visentin 2015)."""
    P = dict(m.DEFAULT_PERSON, **person); ffm = P["FFM"] / CAL["FFM"]
    D = CAL["musc_SI"] * ffm * P["q_m"] + (1 - CAL["musc_SI"]) * P["q_r"]
    wD = CAL["SI_D"] / (CAL["SI_D"] + CAL["SI_P"])
    return wD * D + (1 - wD) * P["q_L"]

# Umrechnung Clamp-Quotient Rd/I (Mittendorfer 2022: mager 713, adipoes NGT 384, adipoes IGT 216 nmol/kgFFM/min pro mU/L)
# in den Faktor q auf die maximale insulinabh. Clearance. Grund: Rd/I wurde nahe der Saettigung gemessen
# (Clamp-Insulin ~119 mU/L adipoes NGT); die Dosis-Wirkung (X50_D) muss herausgerechnet werden [B].
I_CLAMP_OB = 119 * 6.0                        # [L] pmol/L, WashU-Protokoll 50 mU/m2/min, adipoes NGT
def q_from_rdI(ratio, cl_f, par=None):
    X50 = (par or CAL)["X50_D"]; I_lean = I_CLAMP_OB * 0.77; I_g = I_CLAMP_OB * 0.77 / cl_f   # Clamp-Insulin ~ 1/Clearance
    h = lambda I: I / (X50 + I)
    return (h(I_lean) / I_lean) / ratio * I_g / h(I_g)

def build_groups(par=None, qmult=1.0, beta_t2d=19/50):
    global CAL
    if par is not None: CAL = par
    Q_NGT = q_from_rdI(713 / 384, 0.77) * qmult; Q_IGT = q_from_rdI(713 / 216, 0.68) * qmult
    ob = dict(OBESE, q_m=Q_NGT, q_r=Q_NGT, q_L=0.46, cl_f=0.77, Gb=88*mg, Ib=77.0, PFR=1.6)    # Mittendorfer 2022
    ob["beta_f"] = 1 / si_rel(ob)                                    # hyperbolische Kompensation (Kahn 1993)
    return {
        "gesund": dict(),
        "adipös NGT": ob,
        "adipös IGT": dict(OBESE, q_m=Q_IGT, q_r=Q_IGT, q_L=0.26, cl_f=0.68, Gb=92*mg, Ib=130.0, PFR=1.6,
                           beta_f=ob["beta_f"] * 53/102),            # Ferrannini 2003: IGT 53 vs NGT 102
        "T2D": dict(OBESE, q_m=Q_IGT, q_r=Q_IGT, q_L=0.26, cl_f=0.68, Gb=7.08, Ib=73.0, PFR=1.1, RS_f=0.5,
                    beta_f=ob["beta_f"] * beta_t2d),                 # T2D 19 vs NGT 50 (gleiche Studie)
    }, Q_NGT, Q_IGT
GROUPS, Q_NGT, Q_IGT = build_groups()
_ob_ngt = GROUPS["adipös NGT"]
# Daten (nicht zur Kalibrierung genutzt)
DATA = {
    "gesund": dict(ISR_total=39.4, I_mean120=39400/120/1.6),           # RISC
    "adipös NGT": dict(G120=106*mg, Gmean180=19228/180*mg, Imean180=15245/180*6),   # Mittendorfer 2022
    "adipös IGT": dict(G120=167*mg),
    "T2D": dict(G120=11.85, Imean120=41.2e3/120),
}
def run(group, extra=None, t_end=180, par=None):
    P = dict(GROUPS[group]); P.update(extra or {})
    q = m.build(par or CAL, P); t, y = m.ogtt(q, t_end); return t, y, q

def summary(t, y, q):
    G, I = y[2], y[3]
    P = 1 + (q["PFR"] - 1) * np.minimum(t / 120, 1); dG = np.gradient(G, t)
    ISR = P * np.array([m.isr_basal(g, q) for g in G]) + q["drug_isr"] * q["RS"] * np.maximum(dG, 0)
    return dict(G0=G[0], G30=G[30], G60=G[60], G90=G[90], G120=G[120], Gmean120=G[:121].mean(), Gmean180=G.mean(),
                I0=I[0], I30=I[30], I60=I[60], I120=I[120], Imean120=I[:121].mean(), Imean180=I.mean(),
                ISR_total=np.trapezoid(ISR[:121], t[:121]) / 1000, HOMA=G[0] * I[0] / 6 / 22.5)

if __name__ == "__main__":
    print("q NGT %.3f  q IGT/T2D %.3f  beta_f NGT %.2f" % (Q_NGT, Q_IGT, _ob_ngt["beta_f"]))
    out = {}
    for g in GROUPS:
        s = summary(*run(g)); out[g] = s
        print(f"{g:12s}", " ".join(f"{k}={v:.2f}" if v < 50 else f"{k}={v:.0f}" for k, v in s.items() if k in ("G0","G30","G60","G120","Gmean180","I0","Imean120","Imean180","ISR_total")))
        print(f"{'  Daten':12s}", " ".join(f"{k}={v:.2f}" if v < 50 else f"{k}={v:.0f}" for k, v in DATA[g].items()))
    json.dump(out, open("groups.json", "w"), indent=1)

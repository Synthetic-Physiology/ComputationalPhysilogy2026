"""
Glukose-Insulin-Modell zur Forschungsfrage Muskel- vs. Fettverlust unter GLP-1 (finale Version).

Zustaende (5): S Magen [g], Q Darm [g], G Plasmaglukose [mmol/L], I Plasmainsulin [pmol/L],
               X wirksames Insulin [pmol/L] (verzoegert, wirkt auf Aufnahme und Leber).
Fluesse in mmol/min. Insulinsekretion pro m2 Koerperoberflaeche (kuerzt sich mit der Clearance pro m2).

Herkunft: [L] Literatur, [B] Bilanz/abgeleitet, [A] begruendete Annahme, [K] kalibriert innerhalb Literaturstreuung.
"""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq, fsolve

MW = 180.16

# ------------------------------------------------------------------ Grundparameter (gesunde Referenz)
LIT = dict(
    BW=70.0, FFM=52.0, FM=18.0,      # [A] Referenzperson RISC (44 J., BMI ~25)
    Gb=4.95, Ib=38.0,                # [L] Median-Referenz nuechtern (RISC 5,1 / 35)
    V_dl=1.45,                       # [L] Glukose-Verteilungsvolumen dl/kg (Dalla Man 2004)
    EGP_b=2.0,                       # [L] mg/kg/min basale Leberproduktion (Ferrannini 1985: 1,9-2,3)
    f_ii=0.75,                       # [L] insulinunabhaengiger Anteil der basalen Aufnahme (Ferrannini 1985 JCI)
    U_brain_gd=120.0,                # [L] g/Tag Hirnaufnahme (Owen 1967), gesaettigt -> konstant
    SG=0.025,                        # [L/K] Glukoseeffektivitaet min^-1 (orales Minimalmodell, typ. 0,015-0,035)
    SI_D=9.93e-4,                    # [L/K] dl/kg/min pro uU/ml: Insulinwirkung auf Aufnahme bei basalem Insulin (Visentin 2015)
    SI_P=5.48e-4,                    # [L] Leber (Visentin 2015) - nur zur Pruefung der Steigung
    X50_D=330.0,                     # [L/K] pmol/L halbmax. insulinabh. Aufnahme (Rizza 1981: 55 uU/ml)
    X50_L=71.0,                      # [L/K] pmol/L halbmax. EGP-Hemmung, peripher-aequivalent (Rizza 29 uU/ml / Portalfaktor 2,45 Nurjhan)
    sP=0.5,                          # [A/K] Anteil der Glukoseeffektivitaet ueber Hemmung der Leber
    p2=0.02,                         # [L/K] min^-1 Wirkverzoegerung Insulin (OMM typ. 0,01-0,04)
    musc_SI=0.80,                    # [L] Muskelanteil insulinabh. Aufnahme (DeFronzo; Honka 2018)
    musc_ii=0.30,                    # [A] Muskelanteil insulinunabh. Aufnahme ausser Hirn
    CL=1.6,                          # [L/K] L/min/m2 endogene Insulinclearance im oGTT (RISC)
    t_half_I=4.3,                    # [L] min Plasma-Halbwertszeit Insulin
    beta=119.0,                      # [L/K] pmol/min/m2/mM Glukosesensitivitaet Betazelle (RISC NGT)
    RS=800.0,                        # [L/K] pmol/m2/mM Ratensensitivitaet (Mari-Modell, NGT 680-910)
    PFR=2.0,                         # [L/K] Potenzierung 2 h vs basal (Ferrannini 2003)
    D=75.0, k_abs=0.057,             # [L] g Glukose; Darmresorption min^-1 (Dalla Man 2007)
    GE_max=0.5,                      # [L/K] g/min max. Magenentleerung (2 kcal/min; Bereich 1-4 kcal/min)
    G_thr=10.0, GFR=0.12,            # [L] Nierenschwelle mmol/L, GFR L/min
    w_glucagon=0.6,                  # [A] Anteil der basalen EGP, der von Glukagon abhaengt (Cherrington)
)

# Magen: K und systemischer Anteil f werden fuer jedes GE_max aus zwei Tracer-Ankerwerten berechnet [B]:
# Ferrannini 1985: 72 % der Last bis 210 min systemisch erschienen; Ra(210) = 2,47 mg/kg/min.
def _ra_at(GE, K, f, kab, D, BW, T=210):
    def r(t, y):
        S, Q, C = y; ge = GE * S / (K + S); return [-ge, ge - kab * Q, f * kab * Q]
    s = solve_ivp(r, (0, T), [D, 0, 0], rtol=1e-9, atol=1e-12)
    return f * kab * s.y[1, -1] * 1000 / BW, s.y[2, -1] / D
import os, json as _json
_CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gut_cache.json")
_GE_GRID = np.linspace(0.40, 0.72, 17); _KA_GRID = np.array([0.03, 0.04, 0.057, 0.08, 0.11, 0.15, 0.2])
if os.path.exists(_CACHE):
    _KF = np.array(_json.load(open(_CACHE)))
else:
    _KF = np.zeros((len(_KA_GRID), len(_GE_GRID), 2))
    for i, _ka in enumerate(_KA_GRID):
        z = [20, 0.85]
        for j, _ge in enumerate(_GE_GRID):
            z = fsolve(lambda z: [_ra_at(_ge, abs(z[0]), z[1], _ka, 75, 70)[0] - 2.47,
                                  _ra_at(_ge, abs(z[0]), z[1], _ka, 75, 70)[1] - 0.72], z)
            _KF[i, j] = (abs(z[0]), z[1])
    _json.dump(_KF.tolist(), open(_CACHE, "w"))
def gut_params(GE, ka=0.057):
    from scipy.interpolate import RegularGridInterpolator
    out = []
    for c in (0, 1):
        f = RegularGridInterpolator((_KA_GRID, _GE_GRID), _KF[:, :, c])
        out.append(float(f([[np.clip(ka, _KA_GRID[0], _KA_GRID[-1]), np.clip(GE, _GE_GRID[0], _GE_GRID[-1])]])[0]))
    return out[0], out[1]

# ------------------------------------------------------------------ Aufbau einer Person
DEFAULT_PERSON = dict(
    BW=70.0, FFM=52.0, FM=18.0,      # Koerperzusammensetzung
    Gb=None, Ib=None,                # Nuechternanker (None = Referenz); bei Interventionen endogen geloest
    q_m=1.0, q_r=1.0, q_L=1.0,       # Insulinsensitivitaet je Masse: Muskel, uebrige Gewebe, Leber
    cl_f=1.0,                        # Faktor Insulinclearance
    M_rel=None,                      # Muskelmasse relativ zur Referenz (None: wie FFM)
    beta_f=1.0, RS_f=1.0, PFR=None,  # Betazelle relativ zur Referenz
    drug_isr=1.0, drug_glucagon=1.0, drug_ge=1.0,   # GLP-1-Direkteffekte (1 = keine)
)

def build(par, person=None):
    """par: Grundparameter (LIT ggf. kalibriert). person: dict nach DEFAULT_PERSON."""
    P = dict(DEFAULT_PERSON); P.update(person or {})
    p = dict(par)
    V0 = p["V_dl"] * p["BW"] / 10                           # L, Referenz
    ffm_rel = P["FFM"] / p["FFM"]
    q = dict(p); q["person"] = P
    q["V"] = V0 * ffm_rel                                    # [A] Volumen ~ extrazellulaeres Wasser ~ FFM
    si = lambda s: s / p["V_dl"] / 6.0 * V0                  # dl/kg/min/(uU/ml) -> L/min pro pmol/L
    q["U_brain"] = p["U_brain_gd"] / MW / 1440 * 1000        # mmol/min
    EGPb = p["EGP_b"] * p["BW"] / MW                         # mmol/min (Referenz)
    k_ii0 = (p["f_ii"] * EGPb - q["U_brain"]) / p["Gb"]      # [B] L/min
    m_rel_ = P.get("M_rel") or ffm_rel
    q["k_ii"] = k_ii0 * ((1 - p["musc_ii"]) * ffm_rel + p["musc_ii"] * m_rel_)
    q["k_ii_m"] = k_ii0 * p["musc_ii"] * m_rel_
    # insulinabh. Aufnahme: cl_D(X) = cl_max * X/(X50_D + X); Steigung bei Ib = SI_D (Visentin) [B]
    clmax = si(p["SI_D"]) * (p["X50_D"] + p["Ib"]) ** 2 / p["X50_D"]
    m_rel = P.get("M_rel") or ffm_rel                                           # Muskelmasse relativ (Standard ~ FFM) [A]
    q["clmax_m"] = clmax * p["musc_SI"] * m_rel * P["q_m"]
    q["clmax_r"] = clmax * (1 - p["musc_SI"]) * P["q_r"]
    q["qL"] = P["q_L"]
    # Glukoseeffekt auf die Leber [A/K]: Anteil sP der Glukoseeffektivitaet SG*V
    q["k_GP"] = p["sP"] * p["SG"] * V0
    q["CL"] = p["CL"] * P["cl_f"]
    q["beta"] = p["beta"] * P["beta_f"]; q["RS"] = p["RS"] * P["RS_f"]
    q["PFR"] = P["PFR"] if P["PFR"] is not None else p["PFR"]
    q["n"] = np.log(2) / p["t_half_I"]
    q["K_ge"], q["f"] = gut_params(p["GE_max"], p["k_abs"])
    q["GE"] = p["GE_max"] * P["drug_ge"]
    # Leber: E0 aus Nuechternbilanz am Anker (Gruppe) [B]; Glukagon-Anteil w
    Ga = P["Gb"] if P["Gb"] is not None else p["Gb"]; Ia = P["Ib"] if P["Ib"] is not None else p["Ib"]
    q["Ga"], q["Ia"] = Ga, Ia
    for k in ("X50_D", "X50_L", "GFR", "G_thr"): q[k] = p[k]
    U = uptake(Ga, Ia, q)
    q["E0"] = (U + q["k_GP"] * Ga) / hep(Ia, q)                              # EGP(Ga,Ia) = U  (ohne Medikament)
    q["glucagon"] = 1 - p["w_glucagon"] * (1 - P["drug_glucagon"])
    # Betazelle: ISR(G) = ISR5 + beta*(G-5); ISR5 aus Anker: CL*Ia = ISR(Ga) [B]
    q["ISR5"] = q["CL"] * Ia - q["beta"] * (Ga - 5.0)
    q["drug_isr"] = P["drug_isr"]
    return q

def cl_D(X, q, part="all"):
    h = max(X, 0.0) / (q["X50_D"] + max(X, 0.0))
    return h * {"all": q["clmax_m"] + q["clmax_r"], "m": q["clmax_m"]}[part]

def uptake(G, X, q):
    return q["U_brain"] + q["k_ii"] * G + cl_D(X, q) * G + q["GFR"] * max(G - q["G_thr"], 0.0)

def hep(X, q):
    return 1.0 / (1.0 + q["qL"] * max(X, 0.0) / q["X50_L"])

def egp(G, X, q):
    return max(q["E0"] * q["glucagon"] * hep(X, q) - q["k_GP"] * G, 0.0)

def isr_basal(G, q):
    return q["drug_isr"] * max(q["ISR5"] + q["beta"] * (G - 5.0), 0.0)

def fasting(q):
    """Nuechterngleichgewicht (G, I): EGP = Aufnahme, I = ISR/CL."""
    f = lambda G: egp(G, isr_basal(G, q) / q["CL"], q) - uptake(G, isr_basal(G, q) / q["CL"], q)
    G = brentq(f, 2.5, 25.0); return G, isr_basal(G, q) / q["CL"]

def rhs(t, y, q):
    S, Qg, G, I, X = y
    ge = q["GE"] * S / (q["K_ge"] + S)
    Ra = q["f"] * q["k_abs"] * Qg * 1000 / MW
    dG = (egp(G, X, q) + Ra - uptake(G, X, q)) / q["V"]
    P = 1 + (q["PFR"] - 1) * min(t / 120.0, 1.0)            # Potenzierung (Mari), oGTT-Zeitverlauf
    ISR = P * isr_basal(G, q) + q["drug_isr"] * q["RS"] * max(dG, 0.0)
    return [-ge, ge - q["k_abs"] * Qg, dG, q["n"] * (ISR / q["CL"] - I), q["p2"] * (I - X)]

def ogtt(q, t_end=180, dose=None):
    G0, I0 = fasting(q)
    y0 = [q["D"] if dose is None else dose, 0.0, G0, I0, I0]
    t = np.arange(0, t_end + 1.0)
    s = solve_ivp(rhs, (0, t_end), y0, t_eval=t, args=(q,), method="LSODA", rtol=1e-7, atol=1e-9, max_step=2)
    return s.t, s.y

def fluxes(t, y, q):
    """mg/kg(Referenz-KG)/min: Ra, EGP, Muskel-Mehraufnahme; ISR pmol/min/m2"""
    S, Qg, G, I, X = y; c = MW / q["BW"]
    Ra = q["f"] * q["k_abs"] * Qg * 1000 / MW * c
    E = np.array([egp(g, x, q) for g, x in zip(G, X)]) * c
    musc = (q["k_ii_m"] * G + np.array([cl_D(x, q, "m") for x in X]) * G) * c
    musc0 = musc[0]
    return Ra, E, musc - musc0

import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import model as m, intervention as iv
GRAY, INK = "#9a9994", "#14213D"
GC = {"gesund": "#1f9e89", "adipös NGT": "#2a6fdb", "adipös IGT": "#c26a17", "T2D": "#8c5bd6"}
NAME = {"gesund": "Gesund", "adipös NGT": "Adipös, normale Glukosetoleranz", "adipös IGT": "Adipös, Prädiabetes (IGT)", "T2D": "Typ-2-Diabetes"}
plt.rcParams.update({"font.size": 12, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#b5b4ae",
    "axes.grid": True, "grid.color": "#ececea", "axes.titlesize": 13, "axes.titleweight": "bold", "axes.titlecolor": INK, "axes.titlelocation": "left", "axes.titlepad": 22})
fig, ax = plt.subplots(2, 4, figsize=(18, 6.6), sharex=True); t = np.arange(181)
res = {}
for j, g in enumerate(GC):
    drug = iv.GLP1_T2D if g == "T2D" else iv.GLP1
    _, y0 = m.ogtt(iv.make(g), 180); _, y1 = m.ogtt(iv.make(g, **iv.STEP1, drug=drug), 180)
    G0, G1, I0, I1 = y0[2], y1[2], y0[3], y1[3]
    dG = G1[:121].mean() - G0[:121].mean(); dI = 100 * (I1[:121].mean() / I0[:121].mean() - 1)
    res[g] = (G0[0], G1[0], G0[120], G1[120], dG, dI)
    a = ax[0, j]
    a.plot(t, G0, color=GRAY, lw=2, label="vor Therapie"); a.plot(t, G1, color=GC[g], lw=2.6, label="unter GLP-1 (STEP 1)")
    a.axhline(7.8, color="#52514e", lw=1, ls=":"); a.set_ylim(3, 13.5)
    if j == 0: a.text(178, 7.95, "2-h-Grenze IGT", ha="right", fontsize=9.5, color="#52514e")
    a.set_title(NAME[g]); a.text(0, 1.01, f"Glukose Mittel 0–120 min {dG:+.2f} mmol/L".replace(".", ",").replace("-", "−"), transform=a.transAxes, fontsize=10.5, color="#52514e", va="bottom")
    if j == 0: a.set_ylabel("Glukose (mmol/L)")
    b = ax[1, j]
    b.plot(t, I0, color=GRAY, lw=2); b.plot(t, I1, color=GC[g], lw=2.6); b.set_ylim(0, 820)
    b.text(0, 1.01, f"Insulin Mittel 0–120 min {dI:+.0f} %".replace("-", "−"), transform=b.transAxes, fontsize=10.5, color="#52514e", va="bottom")
    b.set_xlabel("Zeit (min)"); b.set_xticks([0, 60, 120, 180])
    if j == 0: b.set_ylabel("Insulin (pmol/L)")
from matplotlib.lines import Line2D
fig.legend([Line2D([], [], color=GRAY, lw=2), Line2D([], [], color=INK, lw=2.6)], ["vor Therapie", "unter Semaglutid 2,4 mg (STEP 1: Fett −19 %, Magermasse −10 %, direkte Wirkungen)"],
           loc="lower center", ncol=2, fontsize=11, frameon=False)
fig.tight_layout(rect=(0, 0.06, 1, 1)); fig.savefig("fig/f8_glp_gruppen.png", dpi=160)
for g, r in res.items(): print(g, " ".join(f"{v:.2f}" for v in r))

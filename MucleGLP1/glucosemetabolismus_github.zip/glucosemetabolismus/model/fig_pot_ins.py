import json, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
S = json.load(open("scenarios.json"))
GRAY, TEAL, INK = "#9a9994", "#1f9e89", "#14213D"
GC = {"adipös NGT": "#2a6fdb", "adipös IGT": "#c26a17", "T2D": "#8c5bd6"}
plt.rcParams.update({"font.size": 12, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#b5b4ae",
    "axes.grid": True, "grid.color": "#ececea", "axes.titlesize": 13, "axes.titleweight": "bold", "axes.titlecolor": INK, "axes.titlelocation": "left", "axes.titlepad": 22})
fig, ax = plt.subplots(1, 3, figsize=(18, 4.9)); t = np.arange(181)
for a, g in zip(ax, GC):
    C = S["curves"][g]; sc = S["scen"][g]; b = sc["Ausgang"]["Imean120"]
    a.plot(t, C["Ausgang"]["I"], color=GRAY, lw=2, label="vor Therapie")
    a.plot(t, C["GLP-1 (STEP 1)"]["I"], color=GC[g], lw=2.4, label="GLP-1 (STEP 1: Fett und Magermasse)")
    a.plot(t, C["GLP-1, nur Fettverlust (theoretisch)"]["I"], color=GC[g], lw=2.4, ls="--", label="gleicher Gewichtsverlust nur Fett")
    a.plot(t, C["Krafttraining ohne GLP-1"]["I"], color=TEAL, lw=2.2, ls=":", label="nur Krafttraining, ohne GLP-1")
    txt = "Insulin 0–120 min: " + ", ".join(f"{lab} {100*(sc[k]['Imean120']/b-1):+.0f} %" for lab, k in
        [("GLP-1", "GLP-1 (STEP 1)"), ("nur Fett", "GLP-1, nur Fettverlust (theoretisch)"), ("Training", "Krafttraining ohne GLP-1")])
    a.set_title(g, loc="left"); a.text(0, 1.01, txt, transform=a.transAxes, fontsize=10.5, color="#52514e", va="bottom")
    a.set( xlabel="Zeit (min)", ylabel="Insulin (pmol/L)"); a.set_xticks([0, 30, 60, 90, 120, 150, 180]); a.set_ylim(0, None)
h, l = ax[0].get_legend_handles_labels(); fig.legend(h, l, loc="lower center", ncol=4, fontsize=10, frameon=False)
fig.tight_layout(rect=(0, 0.08, 1, 1)); fig.savefig("fig/f6_insulin.png", dpi=160)

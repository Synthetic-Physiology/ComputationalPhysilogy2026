import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import model as m, intervention as iv
INK = "#14213D"
GC = {"gesund": "#1f9e89", "adipös NGT": "#2a6fdb", "adipös IGT": "#c26a17", "T2D": "#8c5bd6"}
NAME = {"gesund": "Gesund", "adipös NGT": "Adipös, normal", "adipös IGT": "Adipös, IGT", "T2D": "Typ-2-Diabetes"}
plt.rcParams.update({"font.size": 13, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#b5b4ae",
    "axes.grid": True, "grid.color": "#ececea", "axes.titlesize": 15, "axes.titleweight": "bold", "axes.titlecolor": INK, "axes.titlelocation": "left", "axes.titlepad": 12})
fig, ax = plt.subplots(1, 2, figsize=(18, 6.6)); t = np.arange(181)
for g, c in GC.items():
    _, y = m.ogtt(iv.make(g), 180)
    ax[0].plot(t, y[2], color=c, lw=2.8, label=NAME[g]); ax[1].plot(t, y[3], color=c, lw=2.8, label=NAME[g])
    print(g, round(y[2][120],2), round(y[3].max()))
ax[0].axhline(7.8, color="#52514e", lw=1, ls=":"); ax[0].text(100, 7.65, "2-h-Grenze IGT (7,8)", ha="center", va="top", fontsize=11, color="#52514e")
ax[0].set(title="Glukose", ylabel="Glukose (mmol/L)", xlabel="Zeit (min)", ylim=(3, 12.5))
ax[1].set(title="Insulin", ylabel="Insulin (pmol/L)", xlabel="Zeit (min)", ylim=(0, 850))
for a in ax: a.set_xticks([0, 30, 60, 90, 120, 150, 180])
h, l = ax[0].get_legend_handles_labels(); fig.legend(h, l, loc="lower center", ncol=4, fontsize=13, frameon=False)
fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig("fig/f9_gruppen_basis.png", dpi=160)

import numpy as np, warnings, json, model as m, groups as gr, intervention as iv, scenarios as sc
warnings.filterwarnings("ignore")
CAL0 = dict(gr.CAL)
T = np.array([30,60,90,120]); GD=np.array([7.72,7.26,6.28,5.60]); ID=np.array([296,328,262,230.])
def outputs(par):
    gr.CAL = par; gr.GROUPS, _, _ = gr.build_groups(par)
    t,y,q = gr.run("gesund", par=par)
    fitG = np.sqrt(np.mean((y[2][T]/GD-1)**2))*100; fitI = np.sqrt(np.mean((y[3][T]/ID-1)**2))*100
    res = dict(fitG=fitG, fitI=fitI)
    for g in ["adipös NGT","adipös IGT"]:
        d = sc.drug_for(g)
        b = iv.metrics(iv.make(g, par=par))[0]["Gmean120"]
        f = iv.metrics(iv.make(g, xFM=0.193, par=par))[0]["Gmean120"] - b
        l = iv.metrics(iv.make(g, xLBM=0.097, par=par))[0]["Gmean120"] - b
        res[g+" fett"] = f; res[g+" mager"] = l
    return res
base = outputs(dict(CAL0))
keys = ["SG","SI_D","X50_D","X50_L","sP","p2","CL","beta","RS","PFR","GE_max","V_dl","k_abs","EGP_b","f_ii","U_brain_gd","musc_SI","musc_ii","w_glucagon","GFR","t_half_I"]
rows = []
for k in keys:
    eff = {}
    for fac in (0.8, 1.2):
        p = dict(CAL0); p[k] = CAL0[k]*fac
        if k=="GE_max": p[k]=float(np.clip(p[k],0.401,0.719))
        o = outputs(p); eff[fac] = o
    d = lambda key: max(abs(eff[0.8][key]-base[key]), abs(eff[1.2][key]-base[key]))
    rows.append((k, d("fitG"), d("fitI"), d("adipös IGT fett")/abs(base["adipös IGT fett"])*100, d("adipös IGT mager")/abs(base["adipös IGT mager"])*100, d("adipös NGT mager")/abs(base["adipös NGT mager"])*100))
gr.CAL = CAL0; gr.GROUPS,_,_ = gr.build_groups(CAL0)
print("base", {k: round(v,3) for k,v in base.items()})
print(f"{'Param':12s} dFitG(pp) dFitI(pp) IGT-Fett% IGT-Mager% NGT-Mager%")
for r in sorted(rows, key=lambda r: -max(r[3],r[4])):
    print(f"{r[0]:12s} {r[1]:8.2f} {r[2]:8.2f} {r[3]:9.1f} {r[4]:9.1f} {r[5]:9.1f}")
json.dump(rows, open("relevance.json","w"))

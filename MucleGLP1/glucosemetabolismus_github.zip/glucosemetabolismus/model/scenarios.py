"""Szenarien, GLP-1-Zerlegung (Shapley) und Unsicherheitsanalyse (Monte Carlo)."""
import numpy as np, json, itertools, math, warnings
import model as m, groups as gr, intervention as iv
warnings.filterwarnings("ignore")
GROUPS_OB = ["adipös NGT", "adipös IGT", "T2D"]
METRICS = ["G0", "G120", "Gmean120", "Imean120", "ISR_total", "I0"]
CH = ["isr", "glucagon", "fat_periph", "fat_liver", "lean"]
CH_LABEL = {"isr": "GLP-1: Betazelle", "glucagon": "GLP-1: Glukagon", "fat_periph": "Fettverlust: Muskel/Peripherie",
            "fat_liver": "Fettverlust: Leber", "lean": "Magermasseverlust"}

def drug_for(g): return iv.GLP1_T2D if g == "T2D" else iv.GLP1
def x_fat_only(g):
    P = gr.GROUPS[g]; return (iv.STEP1["xFM"] * P["FM"] + iv.STEP1["xLBM"] * P["FFM"]) / P["FM"]

def scenario_defs(g, opt=None):
    o = opt or {}; d = drug_for(g); kw = dict(par=o.get("par"), lean_to_muscle=o.get("lm", 1.0), s_fat=o.get("s_fat", 1.0), alpha=o.get("alpha"))
    qt = o.get("q_train", iv.RT["q_train"])
    return {
        "Ausgang": iv.make(g, **kw),
        "GLP-1 (STEP 1)": iv.make(g, **iv.STEP1, drug=d, **kw),
        "GLP-1 + Muskelerhalt": iv.make(g, xFM=iv.STEP1["xFM"], xLBM=iv.STEP1["xLBM"] * 0.5, q_train=qt, drug=d, **kw),
        "GLP-1, nur Fettverlust (theoretisch)": iv.make(g, xFM=x_fat_only(g), xLBM=0.0, drug=d, **kw),
        "Krafttraining ohne GLP-1": iv.make(g, gain_FFM=o.get("gain_FFM", iv.RT["gain_FFM"]), q_train=qt, **kw),
        "Muskel +10 % ohne GLP-1 (hypothetisch)": iv.make(g, gain_FFM=0.10 * gr.GROUPS[g]["FFM"], q_train=qt, **kw),
    }

def shapley(g, metric="Gmean120", opt=None):
    o = opt or {}; d = drug_for(g); kw = dict(par=o.get("par"), lean_to_muscle=o.get("lm", 1.0), s_fat=o.get("s_fat", 1.0), alpha=o.get("alpha"))
    val = {}
    for r in range(len(CH) + 1):
        for S in itertools.combinations(CH, r):
            q = iv.make(g, **iv.STEP1, drug=d, channels=set(S), **kw)
            val[frozenset(S)] = iv.metrics(q)[0][metric]
    n = len(CH); phi = {}
    for c in CH:
        tot = 0.0
        for r in range(n):
            for S in itertools.combinations([x for x in CH if x != c], r):
                w = math.factorial(r) * math.factorial(n - r - 1) / math.factorial(n)
                tot += w * (val[frozenset(S) | {c}] - val[frozenset(S)])
        phi[c] = tot
    return phi, val[frozenset()], val[frozenset(CH)]

if __name__ == "__main__":
    out = dict(scen={}, shap={}, curves={}, gast={})
    for g in GROUPS_OB + ["gesund"]:
        if g == "gesund":
            defs = {"Ausgang": iv.make(g), "Krafttraining ohne GLP-1": iv.make(g, gain_FFM=iv.RT["gain_FFM"], q_train=1.15),
                    "Muskel +10 % ohne GLP-1 (hypothetisch)": iv.make(g, gain_FFM=5.2, q_train=1.15)}
        else:
            defs = scenario_defs(g)
        out["scen"][g] = {}; out["curves"][g] = {}
        for k, q in defs.items():
            s, t, y = iv.metrics(q); out["scen"][g][k] = s
            out["curves"][g][k] = dict(G=y[2].tolist(), I=y[3].tolist())
        print(f"\n{g}")
        b = out["scen"][g]["Ausgang"]
        for k, s in out["scen"][g].items():
            print(f"  {k:42s} G0 {s['G0']:.2f} G120 {s['G120']:.2f} ({s['G120']-b['G120']:+.2f})  Gm {s['Gmean120']:.2f} ({s['Gmean120']-b['Gmean120']:+.2f})"
                  f"  Im {s['Imean120']:.0f} ({100*(s['Imean120']/b['Imean120']-1):+.0f} %)  ISR {s['ISR_total']:.0f}")
        if g != "gesund":
            out["shap"][g] = {}
            for met in ["Gmean120", "G120", "Imean120", "G0"]:
                phi, v0, v1 = shapley(g, met); out["shap"][g][met] = dict(phi=phi, base=v0, total=v1)
            ph = out["shap"][g]["Gmean120"]["phi"]
            print("  Zerlegung Gmittel:", {CH_LABEL[k]: round(v, 3) for k, v in ph.items()})
            # Magenentleerung in der fruehen Therapiephase (Hjerpsted 2018: Paracetamol-AUC 0-1 h x0,73)
            q = iv.make(g, **iv.STEP1, drug=dict(drug_for(g), drug_ge=1.0)); s1 = iv.metrics(q)[0]
            # drug_ge so waehlen, dass erste Stunde Darmaufnahme x0,73
            from scipy.optimize import brentq
            def first_hour(fge):
                qq = m.build(gr.CAL, dict(m.DEFAULT_PERSON, drug_ge=fge)); t, y = m.ogtt(qq, 60)
                return np.trapezoid(qq["f"] * qq["k_abs"] * y[1], t)
            ref = first_hour(1.0); fge = brentq(lambda f: first_hour(f) / ref - 0.73, 0.2, 1.0)
            q2 = iv.make(g, **iv.STEP1, drug=dict(drug_for(g), drug_ge=fge)); s2 = iv.metrics(q2)[0]
            out["gast"][g] = dict(fge=fge, dGmean=s2["Gmean120"] - s1["Gmean120"], dG120=s2["G120"] - s1["G120"], dGmax=max(iv.run(q2)[1][2]) - max(iv.run(q)[1][2]))
            print("  Magen (frueh, x%.2f): dGmittel %+.2f dG120 %+.2f dGmax %+.2f" % (fge, out["gast"][g]["dGmean"], out["gast"][g]["dG120"], out["gast"][g]["dGmax"]))
    json.dump(out, open("scenarios.json", "w"))

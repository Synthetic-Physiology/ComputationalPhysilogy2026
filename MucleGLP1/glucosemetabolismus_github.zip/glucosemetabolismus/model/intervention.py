"""Interventionen: Gewichtsverlust (Fett/Mager), GLP-1-Direkteffekte, Krafttraining. Nuechternzustand wird neu geloest."""
import numpy as np, model as m, groups as gr

# --- Fettverlust -> Insulinsensitivitaet (Magkos 2016, adipoes NGT, n=9; Clamp bei 5/11/16 % Gewichtsverlust) [L/B]
MK_xFM = np.array([0, 4.9, 9.2, 13.4]) / 50.3
MK_xFFM = np.array([0, 1.5, 2.8, 4.0]) / 53.0
MK_stim = np.array([168, 207, 326, 311]) / 168      # insulinstimulierte Rd-Zunahme relativ
MK_egp = np.array([29, 23, 24, 20]) / 29            # nicht supprimierte EGP im Clamp relativ
Q_FAT = MK_stim / (1 - MK_xFFM)                     # je Muskelmasse [B]
QL_FAT = 1 / MK_egp                                 # Leber [B]
def q_fat(x, s=1.0):  return 1 + s * (float(np.interp(x, MK_xFM, Q_FAT)) - 1)    # ausserhalb: Plateau [A]
def qL_fat(x, s=1.0): return 1 + s * (float(np.interp(x, MK_xFM, QL_FAT)) - 1)

ALPHA = {"gesund": 1.0, "adipös NGT": 1.0, "adipös IGT": 0.5, "T2D": 0.0}   # Betazell-Anpassung [A]
GLP1 = dict(drug_isr=1.45, drug_glucagon=0.86, drug_ge=1.0)                   # Hjerpsted 2018 (adipoes, 12 Wo.)
GLP1_T2D = dict(drug_isr=2.10, drug_glucagon=0.86, drug_ge=1.0)               # Kapitza 2017 (2. Phase x2,1)
STEP1 = dict(xFM=0.193, xLBM=0.097)                                           # Wilding 2021 DXA
RT = dict(gain_FFM=1.0, q_train=1.15)                                         # Metaanalysen ohne Diaet: +1,1 kg (Peterson 2011), +1,5 kg (Benito 2020); Andersen 2003

def make(group, xFM=0.0, xLBM=0.0, gain_FFM=0.0, q_train=1.0, drug=None, alpha=None,
         channels=None, par=None, lean_to_muscle=1.0, s_fat=1.0):
    """Gibt q (Modellparameter) nach Intervention zurueck.
    channels: Teilmenge von {'isr','glucagon','ge','fat_periph','fat_liver','lean','train'} fuer die Zerlegung."""
    par = par or gr.CAL
    base = dict(m.DEFAULT_PERSON, **gr.GROUPS[group]); q0 = m.build(par, base)
    ch = set(channels) if channels is not None else {"isr", "glucagon", "ge", "fat_periph", "fat_liver", "lean", "train"}
    a = ALPHA[group] if alpha is None else alpha
    P = dict(base)
    FFM0 = base["FFM"]; FM0 = base["FM"]
    dFFM = -(xLBM * FFM0) * ("lean" in ch) + gain_FFM * ("train" in ch)
    P["FFM"] = FFM0 + dFFM
    M0 = base.get("M_rel") or FFM0 / par["FFM"]
    P["M_rel"] = M0 * (1 + lean_to_muscle * dFFM / FFM0)          # Anteil der FFM-Aenderung, der Muskel ist [A]
    P["FM"] = FM0 * (1 - xFM); P["BW"] = P["FM"] + FFM0 + dFFM
    if "fat_periph" in ch:
        P["q_m"] = base["q_m"] * q_fat(xFM, s_fat); P["q_r"] = base["q_r"] * q_fat(xFM, s_fat)
    if "train" in ch:
        P["q_m"] = P["q_m"] * q_train
    if "fat_liver" in ch:
        P["q_L"] = base["q_L"] * qL_fat(xFM, s_fat)
    if drug:
        for k in ("isr", "glucagon", "ge"):
            if k in ch: P["drug_" + k] = drug["drug_" + k]
    q = m.build(par, P)
    # Leber-Grundproduktion E0 und Betazell-Lage bleiben Eigenschaften der Person: nicht neu am Anker festsetzen
    r = gr.si_rel(P) / gr.si_rel(base)                         # >1: sensitiver
    adapt = r ** (-a)                                            # hyperbolisch (Kahn 1993), Staerke alpha
    q["E0"] = q0["E0"]
    q["beta"] = q0["beta"] * adapt; q["ISR5"] = q0["ISR5"] * adapt; q["RS"] = q0["RS"] * adapt
    q["glucagon"] = 1 - par["w_glucagon"] * (1 - P["drug_glucagon"])
    return q

def run(q, t_end=180):
    t, y = m.ogtt(q, t_end); return t, y

def metrics(q, t_end=180):
    t, y = run(q, t_end); return gr.summary(t, y, q), t, y

if __name__ == "__main__":
    # ---------- Validierung 1: Magkos 2016 (Gewichtsverlust ohne Medikament, adipoes NGT)
    b, _, _ = metrics(make("adipös NGT"))
    print("Magkos 2016 (5,7/10,9/16,2 % Gewichtsverlust): Modell vs Daten, % Aenderung")
    D = dict(I0=[18.3, 15.5, 12.6, 9.5], Imean120=[12365, 12950, 11137, 9534], Gmean120=[16558, 15790, 17300, 16665])
    for k in D:
        mod = []
        for xf, xl in zip(MK_xFM[1:], MK_xFFM[1:]):
            s, _, _ = metrics(make("adipös NGT", xf, xl)); mod.append(100 * (s[k] / b[k] - 1))
        print(f"  {k:9s} Modell {np.round(mod)}  Daten {np.round(100*(np.array(D[k][1:])/D[k][0]-1))}")
    s, _, _ = metrics(make("adipös NGT", MK_xFM[-1], MK_xFFM[-1])); print("  G0 Modell %+.2f Daten %+.2f mmol/L" % (s["G0"] - b["G0"], (88.6 - 92.7) / 18.016))
    # ---------- Validierung 2: STEP 1 (Semaglutid 2,4 mg, 68 Wo.): Nuechternglukose -8,35 mg/dl
    for g in ["adipös NGT", "adipös IGT"]:
        b, _, _ = metrics(make(g)); s, _, _ = metrics(make(g, **STEP1, drug=GLP1))
        print(f"STEP 1 {g}: dFPG {s['G0']-b['G0']:+.2f} mmol/L (Daten gesamt -0,46) | G120 {b['G120']:.2f} -> {s['G120']:.2f} (normal < 7,8)")

import json, numpy as np, warnings, matplotlib, matplotlib.ticker; matplotlib.use("Agg"); import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")
import model as m, groups as gr, intervention as iv, scenarios as sc, calibrate as cb
BLUE, ORANGE, TEAL, PURPLE, GRAY, INK, INK2 = "#2a6fdb", "#c26a17", "#1f9e89", "#8c5bd6", "#9a9994", "#14213D", "#52514e"
GC = {"gesund": GRAY, "adipös NGT": BLUE, "adipös IGT": ORANGE, "T2D": PURPLE}
plt.rcParams.update({"font.size": 12, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#b5b4ae",
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": "#ececea",
    "legend.frameon": False, "axes.titlesize": 13, "axes.titleweight": "bold", "axes.titlecolor": INK, "axes.titlelocation": "left"})
S = json.load(open("scenarios.json")); MC = json.load(open("mc_summary.json")); R = json.load(open("mc.json"))
T5 = [0, 30, 60, 90, 120]; GD = [4.95] + list(cb.GD); ID = [38] + list(cb.ID)

# ---------- 1 Gesund: Kalibrierung
r = cb.predict(gr.CAL)
band = np.array([[gr.summary(*gr.run("gesund", par=dict(m.LIT, **x["cal"])))["G120"]] for x in R[:1]])
fig, ax = plt.subplots(1, 3, figsize=(17, 4.8))
# MC-Band
Gs, Is = [], []
for x in R[:150]:
    t, y, q = gr.run("gesund", par=dict(m.LIT, **x["cal"])); Gs.append(y[2][:181]); Is.append(y[3][:181])
Gs, Is = np.array(Gs), np.array(Is); tt = np.arange(181)
for a, Y, arr, d, err, ttl, yl in [(ax[0], r["G"], Gs, GD, [0] + [0.25]*4, "Glukose", "mmol/L"), (ax[1], r["I"], Is, ID, [0] + list(0.12*np.array(ID[1:])), "Insulin", "pmol/L")]:
    a.fill_between(tt, np.percentile(arr, 5, 0), np.percentile(arr, 95, 0), color=BLUE, alpha=0.15, lw=0, label="90 %-Band (Parameterunsicherheit)")
    a.plot(tt, Y[:181], color=BLUE, lw=2.2, label="Modell (kalibriert)")
    a.errorbar(T5, d, yerr=err, fmt="o", color=INK, ms=6, capsize=3, label="Medianreferenz (4 Kohorten)")
    a.set(title=ttl, xlabel="Zeit nach 75 g Glukose (min)", ylabel=yl); a.set_xticks([0, 30, 60, 90, 120, 150, 180])
ax[1].axhline(39400/120/1.6, color=TEAL, ls="--", lw=1.4, label="RISC: mittleres Insulin 0–120 min")
ax[0].legend(fontsize=9, loc="upper right"); ax[1].legend(fontsize=9, loc="upper right")
t300 = np.arange(301)
ax[2].plot(t300, r["Ra"], color=ORANGE, lw=2, label="Aufnahme aus dem Darm")
ax[2].plot(t300, r["EGP"], color=PURPLE, lw=2, label="Leberproduktion")
ax[2].plot([45, 210], [0.62, 0.85], "s", color=PURPLE, mfc="white", mew=2, ms=8, label="Leber, Tracer (Ferrannini 1985)")
ax[2].plot([210], [2.47], "s", color=ORANGE, mfc="white", mew=2, ms=8, label="Darm, Tracer (Ankerwert)")
ax[2].set(title="Innere Glukoseflüsse", xlabel="Zeit (min)", ylabel="mg/kg/min"); ax[2].legend(fontsize=9, loc="center left", bbox_to_anchor=(0.36, 0.62))
fig.tight_layout(); fig.savefig("fig/f1_gesund.png", dpi=160); plt.close()

# ---------- 2 Gruppen: Vorhersage vs Daten
G = json.load(open("groups.json"))
fig, ax = plt.subplots(1, 2, figsize=(15, 4.9))
for g in gr.GROUPS:
    t, y, q = gr.run(g); ax[0].plot(t, y[2], color=GC[g], lw=2.2, label=g)
dat = {"adipös NGT": [(0, 4.88), (120, 5.88)], "adipös IGT": [(0, 5.11), (120, 9.27)], "T2D": [(0, 7.08), (120, 11.85)], "gesund": list(zip(T5, GD))}
for g, pts in dat.items():
    ax[0].plot(*zip(*pts), "o", color=GC[g], mfc="white", mew=2, ms=8)
ax[0].plot([], [], "o", color=INK, mfc="white", mew=2, label="Studiendaten")
ax[0].axhline(7.8, color=INK2, lw=0.8, ls=":"); ax[0].text(182, 7.8, "IGT-Grenze", va="center", fontsize=9, color=INK2)
ax[0].set(title="Glukose im oGTT je Gruppe", xlabel="Zeit (min)", ylabel="mmol/L"); ax[0].legend(fontsize=9, loc="lower right"); ax[0].set_xlim(0, 200); ax[0].set_ylim(0, 13)
items = [("adipös NGT", "G120", 106/18.016, "2-h-Glukose"), ("adipös NGT", "Gmean180", 19228/180/18.016, "Glukose-Mittel 0–180"),
         ("adipös NGT", "Imean180", 15245/180*6, "Insulin-Mittel 0–180"), ("adipös IGT", "G120", 167/18.016, "2-h-Glukose"),
         ("T2D", "G120", 11.85, "2-h-Glukose"), ("T2D", "Imean120", 41.2e3/120, "Insulin-Mittel 0–120"),
         ("gesund", "ISR_total", 39.4, "Gesamtsekretion (RISC)")]
dev = [100 * (G[g][k] / d - 1) for g, k, d, _ in items]
cols = [GC[g] for g, *_ in items]
ax[1].barh(range(len(items)), dev, color=cols, height=0.6)
for i, v in enumerate(dev): ax[1].text(v + (1 if v >= 0 else -1), i, f"{v:+.0f} %", va="center", ha="left" if v >= 0 else "right", fontsize=10, color=INK)
ax[1].set_yticks(range(len(items)), [f"{g}: {lab}" for g, _, _, lab in items], fontsize=10); ax[1].invert_yaxis()
ax[1].axvline(0, color=INK, lw=0.8); ax[1].axvspan(-10, 10, color=TEAL, alpha=0.08, lw=0)
ax[1].set(title="Abweichung Modell vs. Daten (nicht kalibriert)", xlabel="%"); ax[1].set_xlim(-35, 40); ax[1].grid(axis="y", visible=False)
fig.tight_layout(); fig.savefig("fig/f2_gruppen.png", dpi=160); plt.close()

# ---------- 3 Intervention validiert: Magkos + STEP 1
fig, ax = plt.subplots(1, 2, figsize=(17, 4.6), gridspec_kw=dict(width_ratios=[1.25, 1]))
b = iv.metrics(iv.make("adipös NGT"))[0]; wl = 100 * (1 - np.array([0, 98.0, 92.9, 87.6]) / 103.8)
wl = np.array([0, 5.7, 10.9, 16.2])
D = dict(I0=[18.3, 15.5, 12.6, 9.5], Imean120=[12365, 12950, 11137, 9534], Gmean120=[16558, 15790, 17300, 16665])
lab = dict(I0="Nüchterninsulin", Imean120="Insulin im oGTT", Gmean120="Glukose im oGTT")
for k, c in zip(D, [BLUE, ORANGE, TEAL]):
    mod = [0] + [100 * (iv.metrics(iv.make("adipös NGT", xf, xl))[0][k] / b[k] - 1) for xf, xl in zip(iv.MK_xFM[1:], iv.MK_xFFM[1:])]
    ax[0].plot(wl, mod, color=c, lw=2.2, label=f"{lab[k]} Modell")
    ax[0].plot(wl, 100 * (np.array(D[k]) / D[k][0] - 1), "o", color=c, mfc="white", mew=2, ms=8, label=f"{lab[k]} Magkos 2016")
ax[0].axhline(0, color=INK, lw=0.8); ax[0].set(title="Gewichtsverlust ohne Medikament (Magkos 2016)", xlabel="Gewichtsverlust (%)", ylabel="Änderung (%)")
ax[0].legend(fontsize=8.5, ncol=1, loc="center left", bbox_to_anchor=(1.0, 0.5))
vals = []
for g in ["adipös NGT", "adipös IGT"]:
    b0 = iv.metrics(iv.make(g))[0]; s1 = iv.metrics(iv.make(g, **iv.STEP1, drug=iv.GLP1))[0]; vals.append(s1["G0"] - b0["G0"])
mix = 0.563 * vals[0] + 0.437 * vals[1]
ax[1].bar([0, 1, 2], vals + [mix], color=[BLUE, ORANGE, INK2], width=0.55, label="Modell")
ax[1].bar([3], [-8.35 / 18.016], color=GRAY, width=0.55, label="STEP 1 (Daten)")
for i, v in enumerate(vals + [mix, -8.35 / 18.016]): ax[1].text(i, v - 0.03, f"{v:+.2f}", ha="center", va="top", fontsize=10, color=INK)
ax[1].set_xticks(range(4), ["adipös NGT", "adipös IGT", "Mischung 56/44\n(wie STEP 1)", "STEP 1\ngemessen"])
ax[1].axhline(0, color=INK, lw=0.8); ax[1].set(title="Semaglutid 2,4 mg: Änderung Nüchternglukose", ylabel="mmol/L"); ax[1].set_ylim(-0.8, 0.05)
ax[1].grid(axis="x", visible=False); ax[1].legend(fontsize=9, loc="lower left")
fig.tight_layout(); fig.savefig("fig/f3_interventionen_validiert.png", dpi=160); plt.close()

# ---------- 4 Szenarien mit Unsicherheit
SCN = ["GLP-1 (STEP 1)", "GLP-1 + Muskelerhalt", "GLP-1, nur Fettverlust (theoretisch)", "Krafttraining ohne GLP-1"]
SL = ["GLP-1\n(STEP 1)", "GLP-1 +\nMuskelerhalt", "GLP-1, nur\nFett (theor.)", "Krafttraining\nohne GLP-1"]
fig, ax = plt.subplots(1, 2, figsize=(16, 5))
w = 0.26
for j, g in enumerate(sc.GROUPS_OB):
    for i, k in enumerate(SCN):
        med, lo, hi = MC[g][k]; x = i + (j - 1) * w
        ax[0].bar(x, med, w * 0.92, color=GC[g], label=g if i == 0 else None)
        ax[0].errorbar(x, med, yerr=[[med - lo], [hi - med]], color=INK, capsize=2, lw=1)
    b0 = S["scen"][g]["Ausgang"]
    ax[1].bar(np.arange(4) + (j - 1) * w, [100 * (S["scen"][g][k]["Imean120"] / b0["Imean120"] - 1) for k in SCN], w * 0.92, color=GC[g], label=g)
ax[0].set_xticks(range(4), SL); ax[0].axhline(0, color=INK, lw=0.8)
ax[0].set(title="Mittlere Glukose 0–120 min: Änderung (Median, 90 %-Bereich)", ylabel="mmol/L"); ax[0].legend(fontsize=9, loc="lower right"); ax[0].grid(axis="x", visible=False)
ax[1].set_xticks(range(4), SL); ax[1].axhline(0, color=INK, lw=0.8)
ax[1].set(title="Insulin im oGTT: Änderung (Betazellbelastung)", ylabel="%"); ax[1].legend(fontsize=9, loc="lower right"); ax[1].grid(axis="x", visible=False)
fig.tight_layout(); fig.savefig("fig/f4_szenarien.png", dpi=160); plt.close()

# ---------- 5 Zerlegung (Shapley) als Wasserfall
CHC = {"isr": BLUE, "glucagon": TEAL, "fat_periph": ORANGE, "fat_liver": "#e0a35c", "lean": PURPLE}
CHS = {"isr": "Betazelle", "glucagon": "Glukagon", "fat_periph": "Fett→Muskel", "fat_liver": "Fett→Leber", "lean": "Magermasse"}
MECH = {"isr": "GLP-1: Betazelle – cAMP ↑, mehr Insulin je Glukose", "glucagon": "GLP-1: Glukagon ↓ – Leber produziert weniger",
        "fat_periph": "Fettverlust → Muskel: Insulinsignal intakt, mehr GLUT4", "fat_liver": "Fettverlust → Leber: Insulin hemmt Leber besser",
        "lean": "Magermasseverlust: kleinere Glukosesenke, kleineres Volumen"}
from matplotlib.patches import Patch
fig, ax = plt.subplots(1, 3, figsize=(18, 5.8), sharey=False)
for a, g in zip(ax, sc.GROUPS_OB):
    sh = S["shap"][g]["Gmean120"]; cur = sh["base"]
    a.bar(0, cur, color=GRAY, width=0.6); a.text(0, cur + 0.05, f"{cur:.2f}", ha="center", fontsize=10, color=INK)
    for i, c in enumerate(sc.CH, 1):
        v = sh["phi"][c]; a.bar(i, v, bottom=cur, color=CHC[c], width=0.6)
        a.text(i, cur + v + (0.05 if v > 0 else -0.05), f"{v:+.2f}", ha="center", va="bottom" if v > 0 else "top", fontsize=10, color=INK)
        cur += v
    a.bar(6, cur, color=INK2, width=0.6); a.text(6, cur + 0.05, f"{cur:.2f}", ha="center", fontsize=10, color=INK)
    a.set_xticks(range(7), ["vorher"] + [CHS[c] for c in sc.CH] + ["mit GLP-1"], rotation=30, ha="right", fontsize=10)
    lo = min(sh["total"], sh["base"]) - 1.2; a.set_ylim(max(lo, 0), sh["base"] + 0.6)
    a.set(title=g, ylabel="mittlere Glukose 0–120 min (mmol/L)"); a.grid(axis="x", visible=False)
fig.legend(handles=[Patch(color=CHC[c], label=MECH[c]) for c in sc.CH], loc="lower center", ncol=3, fontsize=10.5, frameon=False)
fig.tight_layout(rect=(0, 0.11, 1, 1)); fig.savefig("fig/f5_zerlegung.png", dpi=160); plt.close()

# ---------- 6 Potenzial: GLP-1 vs nur Fett
fig, ax = plt.subplots(1, 3, figsize=(18, 4.9))
t = np.arange(181)
for a, g in zip(ax, sc.GROUPS_OB):
    C = S["curves"][g]
    a.plot(t, C["Ausgang"]["G"], color=GRAY, lw=2, label="vor Therapie")
    a.plot(t, C["GLP-1 (STEP 1)"]["G"], color=GC[g], lw=2.4, label="GLP-1 (STEP 1: Fett und Magermasse)")
    a.plot(t, C["GLP-1, nur Fettverlust (theoretisch)"]["G"], color=GC[g], lw=2.4, ls="--", label="gleicher Gewichtsverlust nur Fett")
    a.plot(t, C["Krafttraining ohne GLP-1"]["G"], color=TEAL, lw=2.2, ls=":", label="nur Krafttraining, ohne GLP-1")
    med, lo, hi = MC[g]["potential_rel"]
    a.text(0.98, 0.95, f"ungenutztes Potenzial:\n{-med:.0f} % mehr Senkung\n(90 %: {-hi:.0f}–{-lo:.0f} %)", transform=a.transAxes, ha="right", va="top", fontsize=10, color=INK)
    a.set(title=g, xlabel="Zeit (min)", ylabel="Glukose (mmol/L)"); a.set_xticks([0, 30, 60, 90, 120, 150, 180])
h, l = ax[0].get_legend_handles_labels(); fig.legend(h, l, loc="lower center", ncol=4, fontsize=10)
fig.tight_layout(rect=(0, 0.08, 1, 1)); fig.savefig("fig/f6_potenzial.png", dpi=160); plt.close()

# ---------- 7 Fett vs Magermasse (Verhaeltnis, MC)
fig, ax = plt.subplots(1, 2, figsize=(14, 4.6))
for j, g in enumerate(sc.GROUPS_OB):
    f = MC[g]["fat"]; l = MC[g]["lean"]; d = MC[g]["drug"]
    for i, (v, c) in enumerate([(f, ORANGE), (l, PURPLE), (d, BLUE)]):
        x = j + (i - 1) * 0.26; ax[0].bar(x, v[0], 0.24, color=c, label=["Fettverlust (Muskel+Leber)", "Magermasseverlust", "GLP-1 direkt (Betazelle+Glukagon)"][i] if j == 0 else None)
        ax[0].errorbar(x, v[0], yerr=[[v[0] - v[1]], [v[2] - v[0]]], color=INK, capsize=2, lw=1)
ax[0].set_xticks(range(3), sc.GROUPS_OB); ax[0].axhline(0, color=INK, lw=0.8); ax[0].grid(axis="x", visible=False)
ax[0].set(title="Beiträge zur Glukoseänderung (Median, 90 %)", ylabel="Δ mittlere Glukose (mmol/L)"); ax[0].legend(fontsize=9, loc="lower left")
data = [[abs((r["shap"][g]["fat_periph"] + r["shap"][g]["fat_liver"]) / r["shap"][g]["lean"]) for r in R] for g in sc.GROUPS_OB]
bp = ax[1].boxplot(data, vert=False, whis=(5, 95), showfliers=False, patch_artist=True, widths=0.5)
for p, g in zip(bp["boxes"], sc.GROUPS_OB): p.set_facecolor(GC[g]); p.set_alpha(0.35); p.set_edgecolor(GC[g])
for med in bp["medians"]: med.set_color(INK)
ax[1].set_yticks([1, 2, 3], sc.GROUPS_OB); ax[1].set_xscale("log"); ax[1].set_xticks([2, 3, 5, 10, 20], ["2:1", "3:1", "5:1", "10:1", "20:1"]); ax[1].xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax[1].set(title="Verhältnis Fettnutzen : Muskelschaden (400 Modellvarianten)", xlabel="Fett : Magermasse"); ax[1].grid(axis="y", visible=False)
fig.tight_layout(); fig.savefig("fig/f7_fett_vs_muskel.png", dpi=160); plt.close()
print("ok")

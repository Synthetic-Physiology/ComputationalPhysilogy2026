# Glucosemetabolismus: GLP-1, muscle and fat

A physiological glucose-insulin model built from published study values separates the effects of GLP-1 receptor agonists into fat loss, muscle loss and direct drug actions. Skeletal muscle is the main insulin-dependent glucose sink, so the muscle lost under GLP-1 gives back 8–12 % of the glucose-lowering effect, most of all in prediabetes. Fat loss still dominates, and combining GLP-1 with resistance training to preserve muscle works best.

**Interactive simulator:** [`docs/index.html`](docs/index.html). Open it in any browser, or enable GitHub Pages (Settings → Pages → branch `main`, folder `/docs`).

---

## Projekt (deutsch)

Wahlfach Computational Physiology (Vorklinik). Das Modell simuliert den 75-g-oGTT für vier Ausgangslagen (gesund, adipös mit normaler Glukosetoleranz, adipös mit IGT, Typ-2-Diabetes) und zerlegt die Wirkung von Semaglutid 2,4 mg (STEP 1) in Fettverlust, Magermasseverlust und direkte Arzneimittelwirkungen.

### Modell

- 5 Zustände: Glukose im Magen und Darm, Plasmaglukose, Plasmainsulin, wirksames (verzögertes) Insulin
- Alle Glukoseflüsse absolut (mmol/min); der Nüchternzustand stellt sich nach jeder Intervention neu ein
- Insulinabhängige Aufnahme sättigend, zu 80 % im Skelettmuskel; Muskelmasse folgt der Magermasse
- Betazelle nach Mari (Glukosesensitivität, Ratensensitivität, Potenzierung)
- Kalibriert wird nur die gesunde Referenz (Maximum a posteriori innerhalb der Literaturstreuung); Gruppen und Interventionen sind Vorhersagen

### Ergebnisse (Median über 400 Modellvarianten)

| | adipös NGT | adipös IGT | T2D |
| --- | --- | --- | --- |
| Fettnutzen : Muskelschaden | 8,6 : 1 | 5,3 : 1 | 6,1 : 1 |
| Mehr Wirkung, wenn alles Fett wäre | 5 % | 10 % | 7 % |

Krafttraining allein (+1,0 kg Muskel, Insulinsensitivität je kg Muskel ×1,15) bringt 9–15 % der GLP-1-Wirkung.

### Ordner

| Pfad | Inhalt |
| --- | --- |
| `model/model.py` | Modellkern: Zustände, Flüsse, Nüchternzustand, oGTT |
| `model/calibrate.py` | Kalibrierung der gesunden Referenz → `calibration.json` |
| `model/groups.py` | Gruppen aus Literaturfaktoren |
| `model/intervention.py` | Fettverlust (Magkos 2016), Magermasse, GLP-1-Direktwirkungen, Krafttraining |
| `model/scenarios.py` | Szenarien und Shapley-Zerlegung → `scenarios.json` |
| `model/mc.py`, `mc_summary.py` | Unsicherheitsanalyse, 400 Varianten → `mc.json`, `mc_summary.json` |
| `model/relevance.py` | Parameter-Relevanz (±20 %) |
| `model/figures.py`, `fig_*.py` | Abbildungen → `model/fig/` |
| `docs/index.html` | interaktiver Simulator (JavaScript-Port des Modells) |

### Ausführen

```bash
pip install -r requirements.txt
cd model
python scenarios.py
python mc.py 400        # ca. 8 min
python mc_summary.py
python figures.py
```

Einzelne Rechnung:

```python
import model as m, intervention as iv
q = iv.make("adipös IGT", **iv.STEP1, drug=iv.GLP1)   # Semaglutid wie STEP 1
t, y = m.ogtt(q, 180)                                  # y[2] Glukose (mmol/L), y[3] Insulin (pmol/L)
```

### Wichtigste Quellen

Ferrannini 1985, 2003, 2005 · Rizza 1981 · Visentin 2015 · Dalla Man 2004, 2007 · RISC-Kohorte · Mittendorfer 2022 · Magkos 2016 · Kahn 1993 · Wilding 2021 (STEP 1) · Hjerpsted 2018 · Kapitza 2017 · Friedrichsen 2021 · Andersen 2003 · Peterson 2011 · Benito 2020

### Grenzen

Nur oGTT, keine Mahlzeiten oder Tagesverläufe; Muskelmasse wird der Magermasse gleichgesetzt; der Fetteffekt stammt aus einer Studie (Magkos 2016, n = 9); Gruppenmittelwerte, keine individuelle Vorhersage. Kein medizinischer Rat.
